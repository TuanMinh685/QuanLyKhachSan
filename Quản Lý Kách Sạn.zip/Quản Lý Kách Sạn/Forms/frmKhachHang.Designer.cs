﻿namespace Quản_Lý_Khách_Sạn.Forms
{
    partial class frmKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            lblTieuDe = new Label();
            lblMoTa = new Label();
            lblNgayHienTai = new Label();
            txtTimKiem = new TextBox();
            cboNhomKhach = new ComboBox();
            btnThemKhachHang = new Button();
            pnlDanhSach = new Panel();
            dgvKhachHang = new DataGridView();
            tabChiTiet = new TabControl();
            tpThongTinChung = new TabPage();
            lblThongTinChung = new Label();
            tpLichSu = new TabPage();
            dgvLichSu = new DataGridView();
            tpGhiChu = new TabPage();
            lblGhiChuXem = new Label();
            lblTongHoSo = new Label();
            lblSoKetQua = new Label();
            pnlThongTin = new Panel();
            txtGhiChu = new TextBox();
            lblGhiChu = new Label();
            lblLoiSoGiayTo = new Label();
            txtSoGiayTo = new TextBox();
            lblSoGiayTo = new Label();
            txtDiaChi = new TextBox();
            lblDiaChi = new Label();
            txtEmail = new TextBox();
            lblEmail = new Label();
            txtQuocTich = new TextBox();
            lblQuocTich = new Label();
            dtpNgaySinh = new DateTimePicker();
            lblNgaySinh = new Label();
            cboGioiTinh = new ComboBox();
            lblGioiTinh = new Label();
            txtDienThoai = new TextBox();
            lblDienThoai = new Label();
            txtHoTen = new TextBox();
            lblHoTen = new Label();
            lblNhomBadge = new Label();
            lblTieuDeThongTin = new Label();
            btnHuy = new Button();
            btnCapNhat = new Button();
            tmrTimKiem = new System.Windows.Forms.Timer(components);
            errorProvider = new ErrorProvider(components);
            pnlDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).BeginInit();
            tabChiTiet.SuspendLayout();
            tpThongTinChung.SuspendLayout();
            tpLichSu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).BeginInit();
            tpGhiChu.SuspendLayout();
            pnlThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider).BeginInit();
            SuspendLayout();
            // 
            // lblTieuDe
            // 
            lblTieuDe.AutoSize = true;
            lblTieuDe.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.FromArgb(15, 42, 74);
            lblTieuDe.Location = new Point(18, 10);
            lblTieuDe.Name = "lblTieuDe";
            lblTieuDe.Size = new Size(232, 32);
            lblTieuDe.TabIndex = 9;
            lblTieuDe.Text = "Quản lý khách hàng";
            // 
            // lblMoTa
            // 
            lblMoTa.AutoSize = true;
            lblMoTa.Font = new Font("Segoe UI", 9F);
            lblMoTa.ForeColor = Color.FromArgb(100, 116, 139);
            lblMoTa.Location = new Point(20, 50);
            lblMoTa.Name = "lblMoTa";
            lblMoTa.Size = new Size(245, 15);
            lblMoTa.TabIndex = 8;
            lblMoTa.Text = "Hồ sơ khách hàng và lịch sử lưu trú tập trung";
            // 
            // lblNgayHienTai
            // 
            lblNgayHienTai.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblNgayHienTai.BackColor = Color.White;
            lblNgayHienTai.BorderStyle = BorderStyle.FixedSingle;
            lblNgayHienTai.Font = new Font("Segoe UI", 9F);
            lblNgayHienTai.ForeColor = Color.FromArgb(15, 42, 74);
            lblNgayHienTai.Location = new Point(924, 18);
            lblNgayHienTai.Name = "lblNgayHienTai";
            lblNgayHienTai.Size = new Size(146, 26);
            lblNgayHienTai.TabIndex = 7;
            lblNgayHienTai.Text = "Thứ Ba, 29/09/2026";
            lblNgayHienTai.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtTimKiem
            // 
            txtTimKiem.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem.Font = new Font("Segoe UI", 10F);
            txtTimKiem.ForeColor = Color.FromArgb(30, 41, 59);
            txtTimKiem.Location = new Point(20, 77);
            txtTimKiem.MaxLength = 100;
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.PlaceholderText = "Tìm họ tên, SĐT, số giấy tờ... (Ctrl+F)";
            txtTimKiem.Size = new Size(250, 25);
            txtTimKiem.TabIndex = 6;
            txtTimKiem.TextChanged += txtTimKiem_TextChanged;
            // 
            // cboNhomKhach
            // 
            cboNhomKhach.DropDownStyle = ComboBoxStyle.DropDownList;
            cboNhomKhach.Font = new Font("Segoe UI", 10F);
            cboNhomKhach.FormattingEnabled = true;
            cboNhomKhach.Items.AddRange(new object[] { "Tất cả nhóm khách", "VIP", "Thân thiết", "Mới" });
            cboNhomKhach.Location = new Point(278, 77);
            cboNhomKhach.Name = "cboNhomKhach";
            cboNhomKhach.Size = new Size(170, 25);
            cboNhomKhach.TabIndex = 5;
            cboNhomKhach.SelectedIndexChanged += cboNhomKhach_SelectedIndexChanged;
            // 
            // btnThemKhachHang
            // 
            btnThemKhachHang.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnThemKhachHang.BackColor = Color.FromArgb(245, 158, 11);
            btnThemKhachHang.Cursor = Cursors.Hand;
            btnThemKhachHang.FlatAppearance.BorderSize = 0;
            btnThemKhachHang.FlatStyle = FlatStyle.Flat;
            btnThemKhachHang.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            btnThemKhachHang.ForeColor = Color.FromArgb(15, 42, 74);
            btnThemKhachHang.Location = new Point(929, 74);
            btnThemKhachHang.Name = "btnThemKhachHang";
            btnThemKhachHang.Size = new Size(141, 34);
            btnThemKhachHang.TabIndex = 4;
            btnThemKhachHang.Text = "+  Thêm khách hàng";
            btnThemKhachHang.UseVisualStyleBackColor = false;
            btnThemKhachHang.Click += btnThemKhachHang_Click;
            // 
            // pnlDanhSach
            // 
            pnlDanhSach.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlDanhSach.BackColor = Color.White;
            pnlDanhSach.Controls.Add(dgvKhachHang);
            pnlDanhSach.Controls.Add(tabChiTiet);
            pnlDanhSach.Controls.Add(lblTongHoSo);
            pnlDanhSach.Controls.Add(lblSoKetQua);
            pnlDanhSach.Location = new Point(20, 120);
            pnlDanhSach.Name = "pnlDanhSach";
            pnlDanhSach.Size = new Size(696, 504);
            pnlDanhSach.TabIndex = 3;
            // 
            // dgvKhachHang
            // 
            dgvKhachHang.AllowUserToAddRows = false;
            dgvKhachHang.AllowUserToDeleteRows = false;
            dgvKhachHang.AllowUserToResizeRows = false;
            dgvKhachHang.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvKhachHang.BackgroundColor = Color.White;
            dgvKhachHang.BorderStyle = BorderStyle.None;
            dgvKhachHang.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvKhachHang.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(234, 241, 250);
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(51, 65, 85);
            dataGridViewCellStyle1.Padding = new Padding(8, 0, 0, 0);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(234, 241, 250);
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(51, 65, 85);
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvKhachHang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvKhachHang.ColumnHeadersHeight = 34;
            dgvKhachHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(30, 41, 59);
            dataGridViewCellStyle2.Padding = new Padding(8, 0, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(232, 241, 252);
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(15, 42, 74);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvKhachHang.DefaultCellStyle = dataGridViewCellStyle2;
            dgvKhachHang.EnableHeadersVisualStyles = false;
            dgvKhachHang.GridColor = Color.FromArgb(226, 232, 240);
            dgvKhachHang.Location = new Point(0, 42);
            dgvKhachHang.MultiSelect = false;
            dgvKhachHang.Name = "dgvKhachHang";
            dgvKhachHang.ReadOnly = true;
            dgvKhachHang.RowHeadersVisible = false;
            dgvKhachHang.RowTemplate.Height = 40;
            dgvKhachHang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvKhachHang.Size = new Size(696, 270);
            dgvKhachHang.TabIndex = 0;
            dgvKhachHang.CellPainting += dgvKhachHang_CellPainting;
            dgvKhachHang.SelectionChanged += dgvKhachHang_SelectionChanged;
            // 
            // tabChiTiet
            // 
            tabChiTiet.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tabChiTiet.Controls.Add(tpThongTinChung);
            tabChiTiet.Controls.Add(tpLichSu);
            tabChiTiet.Controls.Add(tpGhiChu);
            tabChiTiet.Font = new Font("Segoe UI", 9F);
            tabChiTiet.Location = new Point(0, 316);
            tabChiTiet.Name = "tabChiTiet";
            tabChiTiet.SelectedIndex = 0;
            tabChiTiet.Size = new Size(696, 188);
            tabChiTiet.TabIndex = 1;
            // 
            // tpThongTinChung
            // 
            tpThongTinChung.BackColor = Color.White;
            tpThongTinChung.Controls.Add(lblThongTinChung);
            tpThongTinChung.Location = new Point(4, 24);
            tpThongTinChung.Name = "tpThongTinChung";
            tpThongTinChung.Padding = new Padding(3);
            tpThongTinChung.Size = new Size(688, 160);
            tpThongTinChung.TabIndex = 0;
            tpThongTinChung.Text = "Thông tin chung";
            // 
            // lblThongTinChung
            // 
            lblThongTinChung.AutoSize = true;
            lblThongTinChung.Font = new Font("Segoe UI", 9.5F);
            lblThongTinChung.ForeColor = Color.FromArgb(30, 41, 59);
            lblThongTinChung.Location = new Point(12, 10);
            lblThongTinChung.Name = "lblThongTinChung";
            lblThongTinChung.Size = new Size(0, 17);
            lblThongTinChung.TabIndex = 0;
            // 
            // tpLichSu
            // 
            tpLichSu.BackColor = Color.White;
            tpLichSu.Controls.Add(dgvLichSu);
            tpLichSu.Location = new Point(4, 24);
            tpLichSu.Name = "tpLichSu";
            tpLichSu.Padding = new Padding(3);
            tpLichSu.Size = new Size(688, 160);
            tpLichSu.TabIndex = 1;
            tpLichSu.Text = "Lịch sử lưu trú (0)";
            // 
            // dgvLichSu
            // 
            dgvLichSu.AllowUserToAddRows = false;
            dgvLichSu.AllowUserToDeleteRows = false;
            dgvLichSu.AllowUserToResizeRows = false;
            dgvLichSu.BackgroundColor = Color.White;
            dgvLichSu.BorderStyle = BorderStyle.None;
            dgvLichSu.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvLichSu.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(234, 241, 250);
            dataGridViewCellStyle3.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(51, 65, 85);
            dataGridViewCellStyle3.Padding = new Padding(8, 0, 0, 0);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(234, 241, 250);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(51, 65, 85);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvLichSu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvLichSu.ColumnHeadersHeight = 34;
            dgvLichSu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvLichSu.ColumnHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = Color.FromArgb(30, 41, 59);
            dataGridViewCellStyle4.Padding = new Padding(8, 0, 0, 0);
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(232, 241, 252);
            dataGridViewCellStyle4.SelectionForeColor = Color.FromArgb(15, 42, 74);
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            dgvLichSu.DefaultCellStyle = dataGridViewCellStyle4;
            dgvLichSu.Dock = DockStyle.Fill;
            dgvLichSu.EnableHeadersVisualStyles = false;
            dgvLichSu.GridColor = Color.FromArgb(226, 232, 240);
            dgvLichSu.Location = new Point(3, 3);
            dgvLichSu.MultiSelect = false;
            dgvLichSu.Name = "dgvLichSu";
            dgvLichSu.ReadOnly = true;
            dgvLichSu.RowHeadersVisible = false;
            dgvLichSu.RowTemplate.Height = 40;
            dgvLichSu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLichSu.Size = new Size(682, 154);
            dgvLichSu.TabIndex = 0;
            dgvLichSu.CellPainting += dgvLichSu_CellPainting;
            // 
            // tpGhiChu
            // 
            tpGhiChu.BackColor = Color.White;
            tpGhiChu.Controls.Add(lblGhiChuXem);
            tpGhiChu.Location = new Point(4, 24);
            tpGhiChu.Name = "tpGhiChu";
            tpGhiChu.Padding = new Padding(3);
            tpGhiChu.Size = new Size(688, 160);
            tpGhiChu.TabIndex = 2;
            tpGhiChu.Text = "Ghi chú";
            // 
            // lblGhiChuXem
            // 
            lblGhiChuXem.AutoSize = true;
            lblGhiChuXem.Font = new Font("Segoe UI", 9.5F);
            lblGhiChuXem.ForeColor = Color.FromArgb(30, 41, 59);
            lblGhiChuXem.Location = new Point(12, 10);
            lblGhiChuXem.MaximumSize = new Size(660, 0);
            lblGhiChuXem.Name = "lblGhiChuXem";
            lblGhiChuXem.Size = new Size(0, 17);
            lblGhiChuXem.TabIndex = 0;
            // 
            // lblTongHoSo
            // 
            lblTongHoSo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblTongHoSo.Font = new Font("Segoe UI", 9F);
            lblTongHoSo.ForeColor = Color.FromArgb(100, 116, 139);
            lblTongHoSo.Location = new Point(522, 15);
            lblTongHoSo.Name = "lblTongHoSo";
            lblTongHoSo.Size = new Size(160, 18);
            lblTongHoSo.TabIndex = 2;
            lblTongHoSo.Text = "0 hồ sơ";
            lblTongHoSo.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lblSoKetQua
            // 
            lblSoKetQua.AutoSize = true;
            lblSoKetQua.Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold);
            lblSoKetQua.ForeColor = Color.FromArgb(15, 42, 74);
            lblSoKetQua.Location = new Point(14, 13);
            lblSoKetQua.Name = "lblSoKetQua";
            lblSoKetQua.Size = new Size(147, 19);
            lblSoKetQua.TabIndex = 3;
            lblSoKetQua.Text = "0 khách hàng gần đây";
            // 
            // pnlThongTin
            // 
            pnlThongTin.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            pnlThongTin.BackColor = Color.White;
            pnlThongTin.Controls.Add(txtGhiChu);
            pnlThongTin.Controls.Add(lblGhiChu);
            pnlThongTin.Controls.Add(lblLoiSoGiayTo);
            pnlThongTin.Controls.Add(txtSoGiayTo);
            pnlThongTin.Controls.Add(lblSoGiayTo);
            pnlThongTin.Controls.Add(txtDiaChi);
            pnlThongTin.Controls.Add(lblDiaChi);
            pnlThongTin.Controls.Add(txtEmail);
            pnlThongTin.Controls.Add(lblEmail);
            pnlThongTin.Controls.Add(txtQuocTich);
            pnlThongTin.Controls.Add(lblQuocTich);
            pnlThongTin.Controls.Add(dtpNgaySinh);
            pnlThongTin.Controls.Add(lblNgaySinh);
            pnlThongTin.Controls.Add(cboGioiTinh);
            pnlThongTin.Controls.Add(lblGioiTinh);
            pnlThongTin.Controls.Add(txtDienThoai);
            pnlThongTin.Controls.Add(lblDienThoai);
            pnlThongTin.Controls.Add(txtHoTen);
            pnlThongTin.Controls.Add(lblHoTen);
            pnlThongTin.Controls.Add(lblNhomBadge);
            pnlThongTin.Controls.Add(lblTieuDeThongTin);
            pnlThongTin.Location = new Point(730, 120);
            pnlThongTin.Name = "pnlThongTin";
            pnlThongTin.Size = new Size(340, 462);
            pnlThongTin.TabIndex = 2;
            // 
            // txtGhiChu
            // 
            txtGhiChu.BorderStyle = BorderStyle.FixedSingle;
            txtGhiChu.Font = new Font("Segoe UI", 9.75F);
            txtGhiChu.ForeColor = Color.FromArgb(30, 41, 59);
            txtGhiChu.Location = new Point(14, 385);
            txtGhiChu.MaxLength = 500;
            txtGhiChu.Multiline = true;
            txtGhiChu.Name = "txtGhiChu";
            txtGhiChu.ScrollBars = ScrollBars.Vertical;
            txtGhiChu.Size = new Size(312, 40);
            txtGhiChu.TabIndex = 1;
            // 
            // lblGhiChu
            // 
            lblGhiChu.AutoSize = true;
            lblGhiChu.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblGhiChu.ForeColor = Color.FromArgb(51, 65, 85);
            lblGhiChu.Location = new Point(14, 368);
            lblGhiChu.Name = "lblGhiChu";
            lblGhiChu.Size = new Size(48, 15);
            lblGhiChu.TabIndex = 2;
            lblGhiChu.Text = "Ghi chú";
            // 
            // lblLoiSoGiayTo
            // 
            lblLoiSoGiayTo.AutoSize = true;
            lblLoiSoGiayTo.Font = new Font("Segoe UI", 8F);
            lblLoiSoGiayTo.ForeColor = Color.FromArgb(220, 38, 38);
            lblLoiSoGiayTo.Location = new Point(14, 350);
            lblLoiSoGiayTo.Name = "lblLoiSoGiayTo";
            lblLoiSoGiayTo.Size = new Size(0, 13);
            lblLoiSoGiayTo.TabIndex = 3;
            lblLoiSoGiayTo.Visible = false;
            // 
            // txtSoGiayTo
            // 
            txtSoGiayTo.BorderStyle = BorderStyle.FixedSingle;
            txtSoGiayTo.Font = new Font("Segoe UI", 9.75F);
            txtSoGiayTo.ForeColor = Color.FromArgb(30, 41, 59);
            txtSoGiayTo.Location = new Point(14, 321);
            txtSoGiayTo.MaxLength = 30;
            txtSoGiayTo.Name = "txtSoGiayTo";
            txtSoGiayTo.Size = new Size(312, 25);
            txtSoGiayTo.TabIndex = 4;
            txtSoGiayTo.TextChanged += txtSoGiayTo_TextChanged;
            txtSoGiayTo.Leave += txtSoGiayTo_Leave;
            // 
            // lblSoGiayTo
            // 
            lblSoGiayTo.AutoSize = true;
            lblSoGiayTo.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblSoGiayTo.ForeColor = Color.FromArgb(51, 65, 85);
            lblSoGiayTo.Location = new Point(14, 304);
            lblSoGiayTo.Name = "lblSoGiayTo";
            lblSoGiayTo.Size = new Size(113, 15);
            lblSoGiayTo.TabIndex = 5;
            lblSoGiayTo.Text = "Số CCCD / Hộ chiếu";
            // 
            // txtDiaChi
            // 
            txtDiaChi.BorderStyle = BorderStyle.FixedSingle;
            txtDiaChi.Font = new Font("Segoe UI", 9.75F);
            txtDiaChi.ForeColor = Color.FromArgb(30, 41, 59);
            txtDiaChi.Location = new Point(14, 269);
            txtDiaChi.MaxLength = 255;
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(312, 25);
            txtDiaChi.TabIndex = 6;
            // 
            // lblDiaChi
            // 
            lblDiaChi.AutoSize = true;
            lblDiaChi.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblDiaChi.ForeColor = Color.FromArgb(51, 65, 85);
            lblDiaChi.Location = new Point(14, 252);
            lblDiaChi.Name = "lblDiaChi";
            lblDiaChi.Size = new Size(44, 15);
            lblDiaChi.TabIndex = 7;
            lblDiaChi.Text = "Địa chỉ";
            // 
            // txtEmail
            // 
            txtEmail.BorderStyle = BorderStyle.FixedSingle;
            txtEmail.Font = new Font("Segoe UI", 9.75F);
            txtEmail.ForeColor = Color.FromArgb(30, 41, 59);
            txtEmail.Location = new Point(14, 217);
            txtEmail.MaxLength = 100;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(312, 25);
            txtEmail.TabIndex = 8;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblEmail.ForeColor = Color.FromArgb(51, 65, 85);
            lblEmail.Location = new Point(14, 200);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 9;
            lblEmail.Text = "Email";
            // 
            // txtQuocTich
            // 
            txtQuocTich.BorderStyle = BorderStyle.FixedSingle;
            txtQuocTich.Font = new Font("Segoe UI", 9.75F);
            txtQuocTich.ForeColor = Color.FromArgb(30, 41, 59);
            txtQuocTich.Location = new Point(176, 165);
            txtQuocTich.MaxLength = 50;
            txtQuocTich.Name = "txtQuocTich";
            txtQuocTich.Size = new Size(150, 25);
            txtQuocTich.TabIndex = 10;
            // 
            // lblQuocTich
            // 
            lblQuocTich.AutoSize = true;
            lblQuocTich.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblQuocTich.ForeColor = Color.FromArgb(51, 65, 85);
            lblQuocTich.Location = new Point(176, 148);
            lblQuocTich.Name = "lblQuocTich";
            lblQuocTich.Size = new Size(59, 15);
            lblQuocTich.TabIndex = 11;
            lblQuocTich.Text = "Quốc tịch";
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.CustomFormat = "dd/MM/yyyy";
            dtpNgaySinh.Font = new Font("Segoe UI", 9.75F);
            dtpNgaySinh.Format = DateTimePickerFormat.Custom;
            dtpNgaySinh.Location = new Point(14, 165);
            dtpNgaySinh.MinDate = new DateTime(1900, 1, 1, 0, 0, 0, 0);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.ShowCheckBox = true;
            dtpNgaySinh.Size = new Size(150, 25);
            dtpNgaySinh.TabIndex = 12;
            // 
            // lblNgaySinh
            // 
            lblNgaySinh.AutoSize = true;
            lblNgaySinh.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblNgaySinh.ForeColor = Color.FromArgb(51, 65, 85);
            lblNgaySinh.Location = new Point(14, 148);
            lblNgaySinh.Name = "lblNgaySinh";
            lblNgaySinh.Size = new Size(60, 15);
            lblNgaySinh.TabIndex = 13;
            lblNgaySinh.Text = "Ngày sinh";
            // 
            // cboGioiTinh
            // 
            cboGioiTinh.DropDownStyle = ComboBoxStyle.DropDownList;
            cboGioiTinh.Font = new Font("Segoe UI", 9.75F);
            cboGioiTinh.FormattingEnabled = true;
            cboGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
            cboGioiTinh.Location = new Point(176, 113);
            cboGioiTinh.Name = "cboGioiTinh";
            cboGioiTinh.Size = new Size(150, 25);
            cboGioiTinh.TabIndex = 14;
            // 
            // lblGioiTinh
            // 
            lblGioiTinh.AutoSize = true;
            lblGioiTinh.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblGioiTinh.ForeColor = Color.FromArgb(51, 65, 85);
            lblGioiTinh.Location = new Point(176, 96);
            lblGioiTinh.Name = "lblGioiTinh";
            lblGioiTinh.Size = new Size(52, 15);
            lblGioiTinh.TabIndex = 15;
            lblGioiTinh.Text = "Giới tính";
            // 
            // txtDienThoai
            // 
            txtDienThoai.BorderStyle = BorderStyle.FixedSingle;
            txtDienThoai.Font = new Font("Segoe UI", 9.75F);
            txtDienThoai.ForeColor = Color.FromArgb(30, 41, 59);
            txtDienThoai.Location = new Point(14, 113);
            txtDienThoai.MaxLength = 20;
            txtDienThoai.Name = "txtDienThoai";
            txtDienThoai.Size = new Size(150, 25);
            txtDienThoai.TabIndex = 16;
            txtDienThoai.KeyPress += txtDienThoai_KeyPress;
            // 
            // lblDienThoai
            // 
            lblDienThoai.AutoSize = true;
            lblDienThoai.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblDienThoai.ForeColor = Color.FromArgb(51, 65, 85);
            lblDienThoai.Location = new Point(14, 96);
            lblDienThoai.Name = "lblDienThoai";
            lblDienThoai.Size = new Size(70, 15);
            lblDienThoai.TabIndex = 17;
            lblDienThoai.Text = "Điện thoại *";
            // 
            // txtHoTen
            // 
            txtHoTen.BorderStyle = BorderStyle.FixedSingle;
            txtHoTen.Font = new Font("Segoe UI", 9.75F);
            txtHoTen.ForeColor = Color.FromArgb(30, 41, 59);
            txtHoTen.Location = new Point(14, 61);
            txtHoTen.MaxLength = 100;
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(312, 25);
            txtHoTen.TabIndex = 18;
            // 
            // lblHoTen
            // 
            lblHoTen.AutoSize = true;
            lblHoTen.Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold);
            lblHoTen.ForeColor = Color.FromArgb(51, 65, 85);
            lblHoTen.Location = new Point(14, 44);
            lblHoTen.Name = "lblHoTen";
            lblHoTen.Size = new Size(66, 15);
            lblHoTen.TabIndex = 19;
            lblHoTen.Text = "Họ và tên *";
            // 
            // lblNhomBadge
            // 
            lblNhomBadge.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblNhomBadge.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold);
            lblNhomBadge.Location = new Point(254, 12);
            lblNhomBadge.Name = "lblNhomBadge";
            lblNhomBadge.Size = new Size(72, 22);
            lblNhomBadge.TabIndex = 20;
            lblNhomBadge.Text = "Mới";
            lblNhomBadge.TextAlign = ContentAlignment.MiddleCenter;
            lblNhomBadge.Visible = false;
            // 
            // lblTieuDeThongTin
            // 
            lblTieuDeThongTin.AutoSize = true;
            lblTieuDeThongTin.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold);
            lblTieuDeThongTin.ForeColor = Color.FromArgb(15, 42, 74);
            lblTieuDeThongTin.Location = new Point(14, 10);
            lblTieuDeThongTin.Name = "lblTieuDeThongTin";
            lblTieuDeThongTin.Size = new Size(190, 25);
            lblTieuDeThongTin.TabIndex = 21;
            lblTieuDeThongTin.Text = "Thông tin khách hàng";
            // 
            // btnHuy
            // 
            btnHuy.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnHuy.BackColor = Color.White;
            btnHuy.Cursor = Cursors.Hand;
            btnHuy.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            btnHuy.FlatStyle = FlatStyle.Flat;
            btnHuy.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            btnHuy.ForeColor = Color.FromArgb(15, 42, 74);
            btnHuy.Location = new Point(730, 592);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(84, 34);
            btnHuy.TabIndex = 1;
            btnHuy.Text = "Hủy";
            btnHuy.UseVisualStyleBackColor = false;
            btnHuy.Click += btnHuy_Click;
            // 
            // btnCapNhat
            // 
            btnCapNhat.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnCapNhat.BackColor = Color.FromArgb(245, 158, 11);
            btnCapNhat.Cursor = Cursors.Hand;
            btnCapNhat.FlatAppearance.BorderSize = 0;
            btnCapNhat.FlatStyle = FlatStyle.Flat;
            btnCapNhat.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            btnCapNhat.ForeColor = Color.FromArgb(15, 42, 74);
            btnCapNhat.Location = new Point(918, 592);
            btnCapNhat.Name = "btnCapNhat";
            btnCapNhat.Size = new Size(152, 34);
            btnCapNhat.TabIndex = 0;
            btnCapNhat.Text = "Cập nhật";
            btnCapNhat.UseVisualStyleBackColor = false;
            btnCapNhat.Click += btnCapNhat_Click;
            // 
            // tmrTimKiem
            // 
            tmrTimKiem.Interval = 300;
            tmrTimKiem.Tick += tmrTimKiem_Tick;
            // 
            // errorProvider
            // 
            errorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;
            errorProvider.ContainerControl = this;
            // 
            // frmKhachHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 245, 249);
            ClientSize = new Size(1090, 638);
            Controls.Add(btnCapNhat);
            Controls.Add(btnHuy);
            Controls.Add(pnlThongTin);
            Controls.Add(pnlDanhSach);
            Controls.Add(btnThemKhachHang);
            Controls.Add(cboNhomKhach);
            Controls.Add(txtTimKiem);
            Controls.Add(lblNgayHienTai);
            Controls.Add(lblMoTa);
            Controls.Add(lblTieuDe);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(1106, 677);
            Name = "frmKhachHang";
            Text = "Quản lý khách hàng";
            Load += frmKhachHang_Load;
            pnlDanhSach.ResumeLayout(false);
            pnlDanhSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).EndInit();
            tabChiTiet.ResumeLayout(false);
            tpThongTinChung.ResumeLayout(false);
            tpThongTinChung.PerformLayout();
            tpLichSu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).EndInit();
            tpGhiChu.ResumeLayout(false);
            tpGhiChu.PerformLayout();
            pnlThongTin.ResumeLayout(false);
            pnlThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblMoTa;
        private System.Windows.Forms.Label lblNgayHienTai;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.ComboBox cboNhomKhach;
        private System.Windows.Forms.Button btnThemKhachHang;
        private System.Windows.Forms.Panel pnlDanhSach;
        private System.Windows.Forms.Label lblSoKetQua;
        private System.Windows.Forms.Label lblTongHoSo;
        private System.Windows.Forms.Panel pnlThongTin;
        private System.Windows.Forms.Label lblTieuDeThongTin;
        private System.Windows.Forms.Label lblNhomBadge;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label lblQuocTich;
        private System.Windows.Forms.TextBox txtQuocTich;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblSoGiayTo;
        private System.Windows.Forms.TextBox txtSoGiayTo;
        private System.Windows.Forms.Label lblLoiSoGiayTo;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.TabControl tabChiTiet;
        private System.Windows.Forms.TabPage tpThongTinChung;
        private System.Windows.Forms.Label lblThongTinChung;
        private System.Windows.Forms.TabPage tpLichSu;
        private System.Windows.Forms.TabPage tpGhiChu;
        private System.Windows.Forms.Label lblGhiChuXem;
        private System.Windows.Forms.DataGridView dgvKhachHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHoTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDienThoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoGiayTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLanLuuTru;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNhomKhach;
        private System.Windows.Forms.DataGridView dgvLichSu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLsPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLsThoiGian;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLsTrangThai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLsTongTien;
        private System.Windows.Forms.Timer tmrTimKiem;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}
